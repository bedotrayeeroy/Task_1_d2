$(document).ready(function(){
    var count =0;
         $.ajax({
       url:"https://reqres.in/api/users",
       method:"GET"
         }).done(function(data){ 
           
           var start=count > 0 ? 5 * count : count;
var end= start+5;
var gap='';
 
   gap += '<div class="card-body" id="data">'+
     'User Id = '+ data.data[0].id + '<br>' +
     'Email address = '+ data.data[0].email + '<br>' +
     'First name = '+ data.data[0].first_name + '<br>' +
     'Last name = '+ data.data[0].last_name + '<br>' +
     '<div>';
 
if(start == data.length){
				count = 0;
				$("#data").empty();
				$("#data").append("List Traversed. Start over!");
				return;
			}
			
			count++;
			$("#data").empty();
			$("#data").append(gap);
  });
         });
       
           
       
     




