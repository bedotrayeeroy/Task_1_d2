$(document).ready(function(){
     var flag=0;
      $("#login").click(function(){
        fetchndisplay();
       if(flag===0)
       alert("error");  
        });
        function fetchndisplay(){
          $.ajax({
        url:"https://reqres.in/api/users",
        method:"GET"
          }).done(function(data){ 
            alert("Success"); 
           flag=1;
           window.location.href = "dasbrd.html";
          });
        
            
        }
      



});



 
  